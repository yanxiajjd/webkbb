import { useState, useEffect } from 'react';
import { StatusResponse, status } from 'minecraft-server-util';
import { serverInfo } from '@/mock/serverData';
import { motion } from 'framer-motion';

interface ServerStatusData {
  online: boolean;
  players: {
    online: number;
    max: number;
  };
  version: string;
}

export function ServerStatus() {
  const [status, setStatus] = useState<ServerStatusData>({
    online: serverInfo.online,
    players: {
      online: serverInfo.playerCount,
      max: serverInfo.maxPlayers
    },
    version: serverInfo.version
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  
  const fetchServerStatus = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Use actual Minecraft Server List Ping (SLP) protocol to query server status
  const response: StatusResponse = await status(serverInfo.queryIp, {
        port: serverInfo.queryPort,
        timeout: 5000,
        protocolVersion: 760 // Protocol version for Minecraft 1.21.4
      });
      
      setStatus({
        online: true,
        players: {
          online: response.players.online,
          max: response.players.max
        },
        version: response.version.name
      });
      
      // Reset retry count on successful connection
      setRetryCount(0);
    } catch (err) {
      console.error('Failed to fetch server status via Minecraft protocol:', err);
      
      // Increment retry count and set appropriate error message
      setRetryCount(prev => prev + 1);
      
      if (retryCount < 3) {
        setError('连接服务器失败，正在重试...');
        // Retry immediately for first 3 attempts
        setTimeout(fetchServerStatus, 1000);
        return;
      }
      
      setStatus(prev => ({ ...prev, online: false }));
      setError('无法连接到服务器，请稍后再试');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Fetch initial status
    fetchServerStatus();
    
    // Refresh status every 30 seconds
    const intervalId = setInterval(fetchServerStatus, 30000);
    
    // Clean up interval on component unmount
    return () => clearInterval(intervalId);
  }, [retryCount]);

  return (
    <div className="bg-white rounded-16 p-6 shadow-xl border border-gray-200 backdrop-blur-sm transition-all duration-300 hover:shadow-2xl">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <h2 className="text-[clamp(1.5rem,3vw,2rem)] font-bold text-gray-800 mb-2">服务器状态</h2>
          <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
            <span className={`w-3 h-3 rounded-full ${status.online ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
            <span className="text-gray-800 font-medium text-lg">
              {status.online ? '在线' : '离线'}
            </span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto md:mx-0">
            <div className="bg-gray-50 rounded-12 p-4 border border-gray-200 hover:border-gray-300 transition-colors duration-300">
              <p className="text-gray-500 text-sm mb-1">服务器IP</p>
              <p className="text-gray-800 font-mono font-medium">{serverInfo.ip}</p>
            </div>
            <div className="bg-gray-50 rounded-12 p-4 border border-gray-200 hover:border-gray-300 transition-colors duration-300">
              <p className="text-gray-500 text-sm mb-1">端口</p>
              <p className="text-gray-800 font-mono font-medium">{serverInfo.port}</p>
            </div>
            <div className="bg-gray-50 rounded-12 p-4 border border-gray-200 hover:border-gray-300 transition-colors duration-300">
              <p className="text-gray-500 text-sm mb-1">版本</p>
              <p className="text-gray-800 font-medium">{status.version}</p>
            </div>
            <div className="bg-gray-50 rounded-12 p-4 border border-gray-200 hover:border-gray-300 transition-colors duration-300">
              <p className="text-gray-500 text-sm mb-1">在线玩家</p>
              {isLoading ? (
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                </div>
              ) : error ? (
                <p className="text-red-500 font-medium">{error}</p>
              ) : (
                <p className="text-gray-800 font-medium">{status.players.online}/{status.players.max}</p>
              )}
            </div>
          </div>
        </div>
        
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          disabled={!status.online || isLoading}
          className="bg-[#4CAF50] hover:bg-[#388E3C] text-white px-8 py-4 rounded-full transition-all duration-300 font-bold text-lg shadow-lg shadow-green-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {status.online ? '立即加入' : '服务器离线'}
        </motion.button>
      </div>
    </div>
  );
}